from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import os, time
import argparse
import numpy as np
from tqdm import tqdm

import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader
from tensorboardX import SummaryWriter

from ATTDOT import ATTDOT
from generate_dataset import generate_dataset
from read_data import read_data
from get_test_input import get_test_input
from get_train_input import get_train_input
import evaluate

def get_all_data(FLAGS):
	dataset = read_data(FLAGS.path + FLAGS.dataset_name)
	train_matrix, testRatings, testNegatives = dataset.trainMatrix, dataset.testRatings, dataset.testNegatives
	
	test_input = get_test_input(testRatings, testNegatives, FLAGS.num_test_negative)
	test_set = generate_dataset(test_input.user_input, test_input.item_input, test_input.ratings)
	test_dataloader = DataLoader(test_set, batch_size=(FLAGS.num_test_negative+1), shuffle=False, num_workers=4)
	
	user_item_mat_mask = np.load(FLAGS.path + 'user_item_mat_mask.npy').item()
	
	item_mat_of_user = user_item_mat_mask['item_mat_of_user']
	user_mat_of_item = user_item_mat_mask['user_mat_of_item']
	item_mask_of_user = user_item_mat_mask['item_mask_of_user']
	user_mask_of_item = user_item_mat_mask['user_mask_of_item']

	return train_matrix, test_dataloader, item_mat_of_user, user_mat_of_item, item_mask_of_user, user_mask_of_item
	
def create_model(train_matrix, item_mat_of_user, user_mat_of_item, item_mask_of_user, user_mask_of_item, FLAGS, device):
	model = ATTDOT(train_matrix, item_mat_of_user, user_mat_of_item, item_mask_of_user, user_mask_of_item, FLAGS, device)
	model.to(device)
	loss_function = nn.BCELoss()
	optimizer = optim.Adam(model.parameters(), lr=FLAGS.lr, weight_decay=FLAGS.weight_decay)
	writer = SummaryWriter()  # For visualization
	return model, loss_function, optimizer, writer


def train(model, train_matrix, loss_function, optimizer, FLAGS, device):
	count = 0
	for epoch in range(FLAGS.epochs):
		model.train()  # Enable dropout (if have).
		
		train_input = get_train_input(train_matrix, FLAGS.num_train_negative)
		train_set = generate_dataset(train_input.user_input, train_input.item_input, train_input.ratings)
		train_dataloader = DataLoader(train_set, batch_size=FLAGS.batch_size, shuffle=True, num_workers=4)

		start_time = time.time()
		loss_list = []
		#for idx, batch_data in tqdm(enumerate(train_dataloader)):
		for idx, batch_data in tqdm(enumerate(train_dataloader)):
            # Assign the user and item on GPU later.
			user = batch_data['user_id'].long().to(device)
			item = batch_data['item_id'].long().to(device)
			label = batch_data['rating'].float().to(device)

			model.zero_grad()
			prediction = model(user, item)
			loss = loss_function(prediction, label)
			loss.backward()
            # nn.utils.clip_grad_norm(models.parameters(), FLAGS.clip_norm)
			optimizer.step()
			
			writer.add_scalar('data/loss', loss.data.item(), count)
			loss_list.append(loss.data.item())
			count += 1

		model.eval()  # Disable dropout (if have).
		HR, NDCG = evaluate.metrics(model, test_dataloader, FLAGS.top_k, device)
		loss = np.mean(np.array(loss_list))
		elapsed_time = time.time() - start_time
		print("Epoch: %d" % epoch + " Epoch time: " + time.strftime(
            "%H: %M: %S", time.gmtime(elapsed_time)))
		print("Hit ratio is %.3f\tNdcg is %.3f\tLoss is %.5f" % (np.mean(HR), np.mean(NDCG), loss))
		
	torch.save(model, 'm.pt')


if __name__ == '__main__':
	DATA_PATH = 'data/'

	parser = argparse.ArgumentParser()
	
	parser.add_argument("--path", default="data/", type=str, help="the path of saved data")
	parser.add_argument("--lr", default=1e-4, type=float, help="learning rate.")
	parser.add_argument("--dropout", default=0.0, type=float, help="dropout rate.")
	parser.add_argument("--weight_decay", default=1e-5, type=float, help="dropout rate.")
	parser.add_argument("--batch_size", default=256, type=int, help="batch size when training.")
	parser.add_argument("--epochs", default=100, type=str, help="training epoches.")
	parser.add_argument("--top_k", default=10, type=int, help="compute metrics@top_k.")
	parser.add_argument("--embed_size", default=128, type=int, help="embedding size for users and items.")
	parser.add_argument("--num_train_negative", default=4, type=int, help="sample negative items for training.")
	parser.add_argument("--num_test_negative", default=99, type=int, help="sample part of negative items for testing.")
	parser.add_argument("--dataset_name", default="ml-1m", type=str, help="the name of dataset")
						
	FLAGS = parser.parse_args()

	use_cuda = torch.cuda.is_available()
	device = torch.device("cuda:0" if use_cuda else "cpu")
    
	train_matrix, test_dataloader, item_mat_of_user, user_mat_of_item, item_mask_of_user, user_mask_of_item = get_all_data(FLAGS)
	model, loss_function, optimizer, writer = create_model(train_matrix, item_mat_of_user, user_mat_of_item, item_mask_of_user, user_mask_of_item, FLAGS, device)
	train(model, train_matrix, loss_function, optimizer, FLAGS, device)