Thses are source codes of AGMF.

Please directly run main.py.