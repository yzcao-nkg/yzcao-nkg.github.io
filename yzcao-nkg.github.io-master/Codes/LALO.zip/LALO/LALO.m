function [accuracy] = LALO(train_data, train_p_target, test_data, test_target, optmParameter)

max_iter = optmParameter.maxIter;
lambda = optmParameter.lambda;
mu = optmParameter.mu;
k = optmParameter.k;

ker = 'rbf'; % Gaussian kernel
par = mean(pdist(train_data)); % the hyperparameter of Gaussian kernel

[S] = ConstructSimilarityMatrix(train_data, k); % construct the similarity matrix of instances

P = train_p_target./(sum(train_p_target,2)); % initialize the label distribution matrix

[H, Aeq, beq, lb, ub, opts] = LabelPropagationSettings(S, train_p_target, mu); % settings of the label propagation problem

for i = 1:max_iter
    [train_outputs, test_outputs] = MulRegression(train_data, P, test_data, lambda, par, ker); % model training
    [P] = LabelPropagation(train_outputs, H, Aeq, beq, lb, ub, opts); % label propagation
end

accuracy = CalAccuracy(test_outputs, test_target); % calculate the test accuracy

end
