clear;clc;

load('sample data');

optmParameter.lambda   = 0.3; % lambda and beta should be searched by cross validation.
optmParameter.beta    = 0.05; 
optmParameter.maxIter = 50;

[accuracy] = SURE(train_data, train_p_target, test_data, test_target, optmParameter);


