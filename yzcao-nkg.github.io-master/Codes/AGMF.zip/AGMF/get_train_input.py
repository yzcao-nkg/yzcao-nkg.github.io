import numpy as np
import random

class get_train_input(object):
	def __init__(self, train, num_train_negative):
		self.user_input, self.item_input, self.ratings = self.get_train_instances(train, num_train_negative)
		
	def get_train_instances(self, train, num_train_negative):
		user_input, item_input, ratings = [], [], []
		num_users, num_items = train.shape
		for (u, i) in train.keys():
			user_input.append(u)
			item_input.append(i)
			ratings.append(1) # positive
            
			for t in range(num_train_negative):
				j = np.random.randint(num_items)
				while (u, j) in train.keys():
					j = np.random.randint(num_items)
				user_input.append(u)
				item_input.append(j)
				ratings.append(0)
		return user_input, item_input, ratings