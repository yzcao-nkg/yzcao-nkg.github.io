% This is an example file on how LALO can be used.

clear;clc;

load('sample data.mat'); % load the data set.

optmParameter.lambda = 0.05; % regularization parameter
optmParameter.mu = 0.005; % regularization parameter
optmParameter.k = 10; % the number of nearest neighbors
optmParameter.maxIter = 50; % the maximum number of iterations

[accuracy] = LALO(train_data, train_p_target, test_data, test_target, optmParameter);