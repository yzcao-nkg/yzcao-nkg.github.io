Please run SURE_demo.m directly.

Thank you!