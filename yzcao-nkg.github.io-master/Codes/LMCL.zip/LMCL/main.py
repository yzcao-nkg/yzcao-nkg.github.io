import argparse
from utils.models import mlp_model, linear_model
import torch
from utils.utils_data import prepare_mnist_data, prepare_kmnist_data, prepare_fashion_data, prepare_cifar10_data, prepare_train_loaders_for_uniform_comp_labels, prepare_train_loaders_for_multi_comp_labels
from utils.utils_algo import accuracy_check
from utils.utils_loss import mae_loss, mse_loss, ce_loss, gce_loss, phuber_ce_loss, unbiased_estimator, log_loss, exp_loss
from cifar_models import densenet, resnet
import numpy as np

torch.manual_seed(0); torch.cuda.manual_seed_all(0)

parser = argparse.ArgumentParser(
	prog='complementary-label learning demo file.',
	usage='Demo with complementary labels.',
	description='A simple demo file with MNIST dataset.',
	epilog='end',
	add_help=True)

parser.add_argument('-lr', help='optimizer\'s learning rate', default=1e-3, type=float)
parser.add_argument('-bs', help='batch_size of ordinary labels.', default=256, type=int)
parser.add_argument('-ds', help='specify a dataset', default='mnist', type=str, choices=['mnist','kmnist','fashion','cifar10'], required=False)
parser.add_argument('-mo', help='model name', default='mlp', choices=['linear', 'mlp', 'resnet', 'densenet'], type=str, required=False)
parser.add_argument('-ep', help='number of epochs', type=int, default=250)
parser.add_argument('-wd', help='weight decay', default=1e-5, type=float)
parser.add_argument('-p', help='Enable usage of multiple GPUs', action='store_true')
parser.add_argument('-s', help='number of complementary labels', default=5, type=int, required=False)
parser.add_argument('-lo', help='specify a loss function', default='log', type=str, choices=['mae','mse','ce','gce','phuber_ce','log','exp'], required=False)
parser.add_argument('-distr', help='generate complementary labels following uniform distribution or not', default=1, type=int, choices=[0,1], required=False)
parser.add_argument('-seed', help = 'Random seed', default=0, type=int, required=False)

args = parser.parse_args()
np.random.seed(args.seed)

device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")

if args.ds == 'mnist':
    full_train_loader, train_loader, test_loader, ordinary_train_dataset, test_dataset, K = prepare_mnist_data(batch_size=args.bs)
elif args.ds == 'kmnist':
    full_train_loader, train_loader, test_loader, ordinary_train_dataset, test_dataset, K = prepare_kmnist_data(batch_size=args.bs)
elif args.ds == 'fashion':
    full_train_loader, train_loader, test_loader, ordinary_train_dataset, test_dataset, K = prepare_fashion_data(batch_size=args.bs)
elif args.ds == 'cifar10':
    full_train_loader, train_loader, test_loader, ordinary_train_dataset, test_dataset, K = prepare_cifar10_data(batch_size=args.bs)

if args.distr == 1:
    partial_matrix_train_loader, dim = prepare_train_loaders_for_uniform_comp_labels(dataname=args.ds, full_train_loader=full_train_loader, batch_size=args.bs)
    #complementary_train_loader, partial_matrix_train_loader, train_data, ccp, dim = load_train_loaders_for_uniform_comp_labels(dataname=args.ds, full_train_loader=full_train_loader, batch_size=args.bs)
    # note that if the datasets do not exist, we may use "prepare_train_loaders_for_uniform_comp_labels" to generate the required datasets in advance. See fetch_datasets.py for more information.
elif args.distr == 0:    
    partial_matrix_train_loader, dim = prepare_train_loaders_for_multi_comp_labels(full_train_loader=full_train_loader, batch_size=args.bs, s=args.s)

if args.lo == 'mae':
    loss_fn = mae_loss
elif args.lo == 'mse':
    loss_fn = mse_loss
elif args.lo == 'ce':
    loss_fn = ce_loss
elif args.lo == 'gce':
    loss_fn = gce_loss
elif args.lo == 'phuber_ce':
    loss_fn = phuber_ce_loss
elif args.lo == 'log':
    loss_fn = log_loss
elif args.lo == 'exp':
    loss_fn = exp_loss

if args.mo == 'mlp':
    model = mlp_model(input_dim=dim, hidden_dim=500, output_dim=K)
elif args.mo == 'linear':
    model = linear_model(input_dim=dim, output_dim=K)
elif args.mo == 'densenet':
    model = densenet(num_classes=K)
elif args.mo == 'resnet':
    model = resnet(depth=32, num_classes=K)

model = model.to(device)

optimizer = torch.optim.Adam(model.parameters(), lr = args.lr, weight_decay = args.wd)

train_accuracy = accuracy_check(loader=train_loader, model=model, device=device)
test_accuracy = accuracy_check(loader=test_loader, model=model, device=device)

print('Epoch: 0. Tr Acc: {}. Te Acc: {}'.format(train_accuracy, test_accuracy))

test_acc_list = []
train_acc_list = []

for epoch in range(args.ep):
    model.train()
    for i, (images, labels) in enumerate(partial_matrix_train_loader):
        X, partialY = images.to(device), labels.to(device)
        optimizer.zero_grad()
        outputs = model(X)
        
        if args.lo == 'exp' or args.lo == 'log':
            average_loss = loss_fn(outputs, partialY.float())
        else:
            average_loss = unbiased_estimator(loss_fn, outputs, partialY.float(), device)
        average_loss.backward()
        optimizer.step()   
    
    model.eval()
    train_accuracy = accuracy_check(loader=train_loader, model=model, device=device)
    test_accuracy = accuracy_check(loader=test_loader, model=model, device=device)

    print('Epoch: {}. Tr Acc: {}. Te Acc: {}.'.format(epoch+1, train_accuracy, test_accuracy))
 
    if epoch >= (args.ep-10):
        test_acc_list.extend([test_accuracy])
        train_acc_list.extend([train_accuracy])
            
avg_test_acc = np.mean(test_acc_list)

avg_train_acc = np.mean(train_acc_list)

print("Average Test Accuracy over Last 10 Epochs:", avg_test_acc)

print("Average Training Accuracy over Last 10 Epochs:", avg_train_acc)