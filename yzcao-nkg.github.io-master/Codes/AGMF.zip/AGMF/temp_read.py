from read_data import read_data
from get_train_input import get_train_input
from generate_dataset import generate_dataset
from torch.utils.data import DataLoader

path = 'data/'
dataset = 'ml-1m'
batch_size = 128
num_train_negative = 4

dataset = read_data(path + dataset)
train, testRatings, testNegatives = dataset.trainMatrix, dataset.testRatings, dataset.testNegatives

#user_negative = np.load('user_negative.npy').item()


train_input = get_train_input(train, num_train_negative)

train_set = generate_dataset(train_input.user_input, train_input.item_input, train_input.ratings)

training_data_generator = DataLoader(
        train_set, batch_size=batch_size, shuffle=True, num_workers=0)
		
		
			train_input = get_train_input(train, num_train_negative)
	train_set = generate_dataset(train_input.user_input, train_input.item_input, train_input.ratings)

	training_data_generator = DataLoader(train_set, batch_size=batch_size, shuffle=True, num_workers=4)