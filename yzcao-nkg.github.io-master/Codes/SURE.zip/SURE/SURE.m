function [accuracy] = SURE(train_data, train_p_target, test_data, test_target, optmParameter)

max_iter = optmParameter.maxIter;
lambda = optmParameter.lambda;
beta = optmParameter.beta;

par = mean(pdist(train_data));
ker = 'rbf';

l = size(test_target, 2);
Aeq = ones(1, l);
beq = 1;
opts = optimoptions('quadprog',...
    'Algorithm','interior-point-convex','Display','off');
lb = sparse(l, 1);
H = 2*speye(l, l);
P = train_p_target;

for iter = 1:max_iter
    [Q, ~] = kernelRidgeRegression(train_data, P, test_data, beta, par, ker);
    [P] = solveQP(train_p_target, Q, H, Aeq, beq, lb, opts, lambda);
end

[~, Ytest] = kernelRidgeRegression(train_data, P, test_data, beta, par, ker);

[accuracy] = CalAccuracy(Ytest, test_target);

end