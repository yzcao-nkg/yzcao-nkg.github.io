This repository gives the implementation for "Learning with Multiple Complementary Labels" (ICML 2020).

Requirements:
Python 3.6
numpy 1.14
Pytorch 1.1
torchvision 0.2

**It is worth noting that the number of complementary labels in our methods cannot be 0.
Therefore, our methods cannot deal with unlabeled data, so you may ignore any unlabeled data and only use our methods on complementarily labeled data.**

Demo:

For experiments when the size $s$ of each set of MCLs is fixed:
	python main.py -ds mnist -mo mlp -lo mae -distr 0 -s 6

For experiments under the discribed data distribution in Section 5: 
	python main.py -ds mnist -mo mlp -lo mae -distr 1

-ds: specifies the dataset
-mo: specifies the model
-lo: specifies the loss function
-distr: indicates whether the experiments are conducted under the discribed data distribution in Section 5 or not.
-s: if -distr 0 exits, we need to specify a value for $s$ (the size $s$ of each complementary label is fixed).
-lr: learning rate
-wd: weight decay

Have fun!