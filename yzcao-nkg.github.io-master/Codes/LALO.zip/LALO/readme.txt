Please directly run LALO.m.
