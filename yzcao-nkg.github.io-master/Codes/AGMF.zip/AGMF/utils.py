import torch


def masked_softmax(vec, mask, dim, device):

	max_vec = torch.max(vec, dim=dim, keepdim=True)[0]
	exps = torch.exp(vec - max_vec)
	masked_exps = exps * mask.float()
	masked_sums = masked_exps.sum(dim, keepdim=True)
	
	is_illegal = (masked_sums <= 0)
	sum_elements = torch.sum(is_illegal).item()
	
	vec_masked_sums = masked_sums.squeeze(2).squeeze(1)
	if(sum_elements >= 1):
		index = (vec_masked_sums==0).nonzero().squeeze(1)
		masked_sums[index] = torch.tensor([[1.0]]).float().to(device) # torch
	return ((masked_exps/masked_sums)*mask.float())