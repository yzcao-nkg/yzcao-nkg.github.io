import torch
import argparse
import torchvision.transforms as transforms
import torch.nn as nn
import torchvision.datasets as dsets

parser = argparse.ArgumentParser()
parser.add_argument('-lr', type=float, default=1e-3)
parser.add_argument('-wd', type=float, default=1e-5)
parser.add_argument('-ep', type=int, default=200)
parser.add_argument('-bs', type=int, default=256)
parser.add_argument('-se', type=int, default=2, help='Taylor expansion series')

args = parser.parse_args()

def taylor_ce_loss(outputs, labels, series):
    n = series
    k = outputs.shape[1]
    soft_max = nn.Softmax(dim=1)
    sm_outputs = soft_max(outputs)
    label_one_hot = nn.functional.one_hot(labels, k).float()
    final_outputs = (sm_outputs * label_one_hot).sum(dim=1)
    
    total_loss = 0
    for i in range(n): # 0 to n-1
        total_loss += torch.pow(torch.tensor([-1.0]), i+1) * torch.pow(final_outputs-1, i+1) * 1.0/(i+1) #\sum_i=0^n(x-1)^(i+1)*(-1)^(i+1)/(i+1)
    average_loss = total_loss.mean()
    return average_loss

class mlp_model(nn.Module):
    def __init__(self, input_dim, hidden_dim, output_dim):
        super(mlp_model, self).__init__()
        self.fc1 = nn.Linear(input_dim, hidden_dim)
        self.relu1 = nn.ReLU()
        self.fc2 = nn.Linear(hidden_dim, output_dim)

    def forward(self, x):
        out = x.view(-1, self.num_flat_features(x))
        out = self.fc1(out)
        out = self.relu1(out)
        out = self.fc2(out)
        return out

    def num_flat_features(self, x):
        size = x.size()[1:]
        num_features = 1
        for s in size:
            num_features *= s
        return num_features

def accuracy_check(loader, model):
    with torch.no_grad():
        total, num_samples = 0, 0
        for i, (images, labels) in enumerate(loader):
            outputs = model(images)
            _, predicted = torch.max(outputs.data, 1)
            total += (predicted == labels).sum().item()
            num_samples += labels.size(0)
    return total / num_samples

train_dataset = dsets.MNIST(root='./data/mnist', train=True, transform=transforms.ToTensor(), download=True)
test_dataset = dsets.MNIST(root='./data/mnist', train=False, transform=transforms.ToTensor())


train_loader = torch.utils.data.DataLoader(dataset=train_dataset, batch_size=args.bs, drop_last=True, shuffle=True)
test_loader = torch.utils.data.DataLoader(dataset=test_dataset, batch_size=args.bs, drop_last=True, shuffle=True)

model = mlp_model(input_dim=28*28, hidden_dim=512, output_dim=10)
loss_fn = taylor_ce_loss
optimizer = torch.optim.Adam(model.parameters(), lr = args.lr, weight_decay = args.wd)

test_accuracy = accuracy_check(loader=test_loader, model=model)

print('Epoch: 0. Te Acc: {}'.format(test_accuracy))

acc_list = []
for epoch in range(args.ep):
    model.train()
    for i, (images, labels) in enumerate(train_loader):
        X, labels = images, labels
        optimizer.zero_grad()
        outputs = model(X)
        average_loss = loss_fn(outputs, labels, args.se)
        average_loss.backward()
        optimizer.step()           
    model.eval()
    test_accuracy = accuracy_check(loader=test_loader, model=model)
    print('Epoch: {}. Te Acc: {}.'.format(epoch+1, test_accuracy))
    if epoch >= (args.ep-10):
        acc_list.append(test_accuracy)

avg_acc = sum(acc_list)/len(acc_list)
print("lr :{}  wd:{} loss:{}".format(args.lr, args.wd, args.lo))
print('series:{}'.format(args.se))
print('avg_accuracy:{}'.format(str(avg_acc)))

