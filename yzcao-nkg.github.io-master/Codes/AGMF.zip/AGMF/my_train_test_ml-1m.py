import pandas as pd
import random
import numpy as np

def re_index(s):
	""" for reindexing the item set. """
	i = 0
	s_map = {}
	for key in s:
		s_map[key] = i
		i += 1
	return s_map

data = pd.read_csv('ratings.dat', sep="::", names = ['user', 'item', 'rating', 'timestamp'], engine = 'python')
data['rating'] = 1

user_set = set(data['user'].unique()) # original user set
item_set = set(data['item'].unique()) # original item set

user_mapping = re_index(user_set)
item_mapping = re_index(item_set)

user_list = [] # index is from 0
item_list = [] # index is from 0

for i in range(len(data)):
    user_list.append(user_mapping[data['user'][i]])
    item_list.append(item_mapping[data['item'][i]])
	
data['user'] = user_list # change the user index here!
data['item'] = item_list # change the item index here!


user_set = set(data['user'].unique()) # current user set
item_set = set(data['item'].unique()) # current item set

data.sort_values(by = ['timestamp'], inplace = True) #ｓｏｒｔ　ｂｙ　ｔｉｍｅｓｔａｍｐ
last_item_mask = data.duplicated(subset = 'user', keep = "last") # mask the last item (by timestamp) of each user

train_data = data[last_item_mask]
test_data = data[~last_item_mask]
    
train_data.sort_values(by=['user', 'timestamp'], inplace = True)
test_data.sort_values(by=['user'], inplace = True)

train_data.to_csv('data/ml-1m.train.rating', header=False, index=False, sep='\t')
test_data.to_csv('data/ml-1m.test.rating', header=False, index=False, sep='\t')

user_bought = {}
user_seq = list(data['user'])
item_seq = list(data['item'])
for i in range(len(data)):
    u = user_seq[i]    
    t = item_seq[i]
    if u not in user_bought:
        user_bought[u] = []
    user_bought[u].append(t)

train_user_bought = {}
train_user_seq = list(train_data['user'])
train_item_seq = list(train_data['item'])

for i in range(len(train_data)):
    u = train_user_seq[i]    
    t = train_item_seq[i]
    if u not in train_user_bought:
        train_user_bought[u] = []
    train_user_bought[u].append(t)
	
user_negative = {}
train_user_negative = {}
test_negative = []

for j in range(len(user_set)):
	user_negative[j] = list(item_set - set(user_bought[j]))
	train_user_negative[j] = list(item_set - set(train_user_bought[j]))
	random.shuffle(user_negative[j])
	test_negative.append([j])
	test_negative[j].extend(user_negative[j][0:99])  # add 99 negative items
	
np.save('data/train_user_negative.npy', train_user_negative)
test_negative = pd.DataFrame(test_negative)
test_negative.to_csv('data/ml-1m.test.negative', header=False, index=False, sep='\t')

# generate item_mat_of_user, item_mask_of_user

user_size = len(user_set)
item_list_of_user = []

for i in range(user_size):
    sort_item = train_data[train_data['user']==i].sort_values(by=['timestamp'], ascending=False)
    item_id = list(sort_item['item'])
    item_list_of_user.append(item_id)

max_num_item = max(len(x) for x in item_list_of_user)
item_mask_of_user = []
item_mat_of_user = []

for i in range(user_size):
    item_vec = np.concatenate([item_list_of_user[i], np.zeros(max_num_item-len(item_list_of_user[i]))])
    item_mask = np.concatenate([np.ones(len(item_list_of_user[i]), dtype=bool), np.zeros(max_num_item-len(item_list_of_user[i]), dtype=bool)])
    item_mask_of_user.append(item_mask)
    item_mat_of_user.append(item_vec)

item_mat_of_user = np.vstack(item_mat_of_user)
item_mask_of_user = np.stack(item_mask_of_user)

# generate user_mat_of_item, user_mask_of_item

item_size = len(item_set)
user_list_of_item = []
for j in range(item_size):
    sort_user = train_data[train_data['item']==j].sort_values(by=['timestamp'], ascending=False)
    user_id = list(sort_user['user'])
    user_list_of_item.append(user_id)
    
max_num_user = max(len(x) for x in user_list_of_item)
user_mask_of_item = []
user_mat_of_item = []

for j in range(item_size):
    user_vec = np.concatenate([user_list_of_item[j], np.zeros(max_num_user-len(user_list_of_item[j]))])
    user_mask = np.concatenate([np.ones(len(user_list_of_item[j]), dtype=bool), np.zeros(max_num_user-len(user_list_of_item[j]), dtype=bool)])
    user_mask_of_item.append(user_mask)
    user_mat_of_item.append(user_vec)

user_mat_of_item = np.vstack(user_mat_of_item)
user_mask_of_item = np.stack(user_mask_of_item)

user_item_mat_mask = dict([('item_mat_of_user',item_mat_of_user), ('item_mask_of_user',item_mask_of_user), ('user_mat_of_item',user_mat_of_item), ('user_mask_of_item',user_mask_of_item)])

np.save('data/user_item_mat_mask.npy', user_item_mat_mask)