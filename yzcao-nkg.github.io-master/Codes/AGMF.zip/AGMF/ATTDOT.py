from __future__ import absolute_import
from __future__ import division

import torch
import torch.nn as nn
import torch.nn.init as init
import torch.nn.functional as F
from utils import masked_softmax
from torch.autograd import Variable
import numpy as np


class ATTDOT(nn.Module):
	def __init__(self, train_matrix, item_mat_of_user, user_mat_of_item, item_mask_of_user, user_mask_of_item, FLAGS, device):
		super(ATTDOT, self).__init__()
		self.user_size = train_matrix.shape[0]
		self.item_size = train_matrix.shape[1]
		self.embed_size = FLAGS.embed_size
		self.dropout = FLAGS.dropout
		self.device = device

		def init_weights(m):
			if type(m) == nn.Linear:
				nn.init.xavier_uniform_(m.weight)
				if m.bias is not None:
					nn.init.constant_(m.bias, 0)
			elif type(m) == nn.Embedding:
				nn.init.uniform_(m.weight)
				#nn.init.normal_(m.weight)

		self.embedding_user_mlp = nn.Embedding(num_embeddings=self.user_size, embedding_dim=self.embed_size)
		self.embedding_item_mlp = nn.Embedding(num_embeddings=self.item_size, embedding_dim=self.embed_size)
		self.embedding_user_mlp.apply(init_weights)
		self.embedding_item_mlp.apply(init_weights)
		
		self.c_item = torch.from_numpy(item_mat_of_user).to(self.device)   #user*n*item
		self.c_user = torch.from_numpy(user_mat_of_item).to(self.device)   #item*n*user
		self.c_item_mask = torch.from_numpy(item_mask_of_user.astype(int)).to(self.device)
		self.c_user_mask = torch.from_numpy(user_mask_of_item.astype(int)).to(self.device)
	
		self.user_att_layer = nn.Sequential(
			nn.Linear(self.embed_size, 1, bias=False),
			nn.Sigmoid()
		)
		self.user_att_layer.apply(init_weights)
		
		self.item_att_layer = nn.Sequential(
			nn.Linear(self.embed_size, 1, bias=False),
			nn.Sigmoid()
		)
		self.item_att_layer.apply(init_weights)
		
		self.predict_layer = nn.Sequential(
			nn.Linear(self.embed_size, 1, bias=False),
			nn.Sigmoid()
		)
		self.predict_layer.apply(init_weights)
		
	def forward(self, user, item):
		embed_user_MLP = self.embedding_user_mlp(user)   #b*e
		embed_item_MLP = self.embedding_item_mlp(item)

		other_user_id = self.c_user[item,:]
		other_item_id = self.c_item[user,:]
		other_user_mask = self.c_user_mask[item,:]
		other_item_mask = self.c_item_mask[user,:]
		other_user_mask[(other_user_id.long()-user.unsqueeze(1).expand(user.shape[0],other_user_id.shape[1]))==0] = 0 # user list for each item
		other_item_mask[(other_item_id.long()-item.unsqueeze(1).expand(item.shape[0],other_item_id.shape[1]))==0] = 0 # item list for each user
		#max_other_user_size = torch.max(torch.sum(other_user_mask,dim=1)).data.item()
		max_other_user_size = 50
		other_user_id = other_user_id.split(max_other_user_size,dim=1)[0]
		other_user_mask = other_user_mask.split(max_other_user_size, dim=1)[0]

		#max_other_item_size = torch.max(torch.sum(other_item_mask, dim=1)).data.item()
		max_other_item_size = 50
		other_item_id = other_item_id.split(max_other_item_size,dim=1)[0]
		other_item_mask = other_item_mask.split(max_other_item_size, dim=1)[0]

		other_user_mask = other_user_mask.unsqueeze(2)
		other_item_mask = other_item_mask.unsqueeze(2) # b * n * 1

		embed_other_user_MLP = self.embedding_user_mlp(other_user_id.long())
		embed_other_item_MLP = self.embedding_item_mlp(other_item_id.long())
		
		embed_items_for_user = embed_user_MLP.unsqueeze(1).expand(item.shape[0],embed_other_item_MLP.shape[1],self.embed_size) * embed_other_item_MLP # b * n * e
		item_att_weights = self.item_att_layer(embed_items_for_user) # b * n * 1
		item_att_weights = masked_softmax(item_att_weights, other_item_mask, 1, self.device)
		
		user_att_embedding = torch.sum(item_att_weights.expand(item.shape[0],embed_other_item_MLP.shape[1], self.embed_size) * embed_other_item_MLP, dim=1)
		user_embedding = embed_user_MLP + user_att_embedding
		
		embed_users_for_item = embed_item_MLP.unsqueeze(1).expand(user.shape[0],embed_other_user_MLP.shape[1],self.embed_size) * embed_other_user_MLP
		user_att_weights = self.user_att_layer(embed_users_for_item)
		user_att_weights = masked_softmax(user_att_weights, other_user_mask, 1, self.device)
		
		item_att_embedding = torch.sum(user_att_weights.expand(user.shape[0],embed_other_user_MLP.shape[1], self.embed_size) * embed_other_user_MLP, dim=1)
		item_embedding = embed_item_MLP + item_att_embedding
		
		final_input = user_embedding * item_embedding
		prediction = self.predict_layer(final_input)

		return prediction.view(-1)
