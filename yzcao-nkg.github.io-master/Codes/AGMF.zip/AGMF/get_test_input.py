class get_test_input(object):
	def __init__(self, testRatings, testNegatives, num_test_negative):
		self.user_input, self.item_input, self.ratings = self.get_test_instances(testRatings, testNegatives, num_test_negative)
      
	def get_test_instances(self, testRatings, testNegatives, num_test_negative):
		user_input, item_input, ratings = [], [], []
		for ui_pair in range(len(testRatings)):
			pair_list = testRatings[ui_pair]
			user_input.append(pair_list[0])
			item_input.append(pair_list[1])
			ratings.append(1)
			
			user_input.extend([pair_list[0]]*num_test_negative) # repeat 99 same users
			item_input.extend(testNegatives[ui_pair]) # add 99 negative items
			ratings.extend([0]*num_test_negative)

		return user_input, item_input, ratings